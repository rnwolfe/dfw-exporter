# HTML Version of the NSX RAML Specification

This is an automatically generated HTML Version of the NSX for vSphere API RAML spec. You can either view it or download it.

To view the dynamic HTML Version of the NSX for vSphere RAML spec on-line, follow this link: 

https://htmlpreview.github.io/?https://github.com/vmware/nsxraml/blob/master/html-version/nsxvapi.html

To view the static HTML Version of the NSX for vSphere RAML spec on-line, follow this link: 

https://htmlpreview.github.io/?https://github.com/vmware/nsxraml/blob/master/html-version/nsxvapi-static.html

To download the dynamic HTML Version of the NSX for vSphere RAML spec, use the raw github link, right click on it and download: 

https://raw.githubusercontent.com/vmware/nsxraml/master/html-version/nsxvapi.html

To download the static HTML Version of the NSX for vSphere RAML spec, use the raw github link, right click on it and download: 

https://raw.githubusercontent.com/vmware/nsxraml/master/html-version/nsxvapi-static.html
